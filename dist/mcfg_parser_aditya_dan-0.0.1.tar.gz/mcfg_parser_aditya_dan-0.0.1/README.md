This is a package for an agenda-based MCFG parser
